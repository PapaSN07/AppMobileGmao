import{b as K,c as Q,k as p}from"./chunk-IETZYUY4.js";import{ka as h,ta as J}from"./chunk-S22TW3MZ.js";import{b as q,d as W,k as G}from"./chunk-LXXOYOJP.js";import{$ as T,Ab as o,Bb as C,Bc as s,Cb as _,Cc as A,Db as O,Kb as j,Pb as F,Qa as w,Qb as r,Rb as U,Sb as R,Ta as M,Y as u,Ya as z,Z as I,Zb as S,a as l,b as d,ba as g,bc as m,cc as $,dc as H,ga as k,ha as E,ib as B,jb as N,jc as P,m as c,mb as L,nb as V,ob as f,pa as v,ua as b,ub as x,wc as D}from"./chunk-XBUTH57D.js";var X=class e{_config={preset:"Aura",primary:"emerald",surface:null,darkTheme:!0,menuMode:"static"};_state={staticMenuDesktopInactive:!1,overlayMenuActive:!1,configSidebarVisible:!1,staticMenuMobileActive:!1,menuHoverActive:!1};layoutConfig=v(this._config);layoutState=v(this._state);configUpdate=new c;overlayOpen=new c;menuSource=new c;resetSource=new c;menuSource$=this.menuSource.asObservable();resetSource$=this.resetSource.asObservable();configUpdate$=this.configUpdate.asObservable();overlayOpen$=this.overlayOpen.asObservable();theme=s(()=>this.layoutConfig()?.darkTheme?"dark":"light");isSidebarActive=s(()=>this.layoutState().overlayMenuActive||this.layoutState().staticMenuMobileActive);isDarkTheme=s(()=>this.layoutConfig().darkTheme);getPrimary=s(()=>this.layoutConfig().primary);getSurface=s(()=>this.layoutConfig().surface);isOverlay=s(()=>this.layoutConfig().menuMode==="overlay");transitionComplete=v(!1);initialized=!1;constructor(){A(()=>{this.layoutConfig()&&this.onConfigUpdate()}),A(()=>{let t=this.layoutConfig();if(!this.initialized||!t){this.initialized=!0;return}this.handleDarkModeTransition(t)});let a=this.layoutConfig();a&&this.toggleDarkMode(a)}handleDarkModeTransition(a){document.startViewTransition?this.startViewTransition(a):(this.toggleDarkMode(a),this.onTransitionEnd())}startViewTransition(a){document.startViewTransition(()=>{this.toggleDarkMode(a)}).ready.then(()=>{this.onTransitionEnd()}).catch(()=>{})}toggleDarkMode(a){(a||this.layoutConfig()).darkTheme?document.documentElement.classList.add("app-dark"):document.documentElement.classList.remove("app-dark")}onTransitionEnd(){this.transitionComplete.set(!0),setTimeout(()=>{this.transitionComplete.set(!1)})}onMenuToggle(){this.isOverlay()&&(this.layoutState.update(a=>d(l({},a),{overlayMenuActive:!this.layoutState().overlayMenuActive})),this.layoutState().overlayMenuActive&&this.overlayOpen.next(null)),this.isDesktop()?this.layoutState.update(a=>d(l({},a),{staticMenuDesktopInactive:!this.layoutState().staticMenuDesktopInactive})):(this.layoutState.update(a=>d(l({},a),{staticMenuMobileActive:!this.layoutState().staticMenuMobileActive})),this.layoutState().staticMenuMobileActive&&this.overlayOpen.next(null))}isDesktop(){return window.innerWidth>991}isMobile(){return!this.isDesktop()}onConfigUpdate(){this._config=l({},this.layoutConfig()),this.configUpdate.next(this.layoutConfig())}onMenuStateChange(a){this.menuSource.next(a)}reset(){this.resetSource.next(!0)}static \u0275fac=function(t){return new(t||e)};static \u0275prov=u({token:e,factory:e.\u0275fac,providedIn:"root"})};var Y=`
    .p-avatar {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: dt('avatar.width');
        height: dt('avatar.height');
        font-size: dt('avatar.font.size');
        background: dt('avatar.background');
        color: dt('avatar.color');
        border-radius: dt('avatar.border.radius');
    }

    .p-avatar-image {
        background: transparent;
    }

    .p-avatar-circle {
        border-radius: 50%;
    }

    .p-avatar-circle img {
        border-radius: 50%;
    }

    .p-avatar-icon {
        font-size: dt('avatar.icon.size');
        width: dt('avatar.icon.size');
        height: dt('avatar.icon.size');
    }

    .p-avatar img {
        width: 100%;
        height: 100%;
    }

    .p-avatar-lg {
        width: dt('avatar.lg.width');
        height: dt('avatar.lg.width');
        font-size: dt('avatar.lg.font.size');
    }

    .p-avatar-lg .p-avatar-icon {
        font-size: dt('avatar.lg.icon.size');
        width: dt('avatar.lg.icon.size');
        height: dt('avatar.lg.icon.size');
    }

    .p-avatar-xl {
        width: dt('avatar.xl.width');
        height: dt('avatar.xl.width');
        font-size: dt('avatar.xl.font.size');
    }

    .p-avatar-xl .p-avatar-icon {
        font-size: dt('avatar.xl.icon.size');
        width: dt('avatar.xl.icon.size');
        height: dt('avatar.xl.icon.size');
    }

    .p-avatar-group {
        display: flex;
        align-items: center;
    }

    .p-avatar-group .p-avatar + .p-avatar {
        margin-inline-start: dt('avatar.group.offset');
    }

    .p-avatar-group .p-avatar {
        border: 2px solid dt('avatar.group.border.color');
    }

    .p-avatar-group .p-avatar-lg + .p-avatar-lg {
        margin-inline-start: dt('avatar.lg.group.offset');
    }

    .p-avatar-group .p-avatar-xl + .p-avatar-xl {
        margin-inline-start: dt('avatar.xl.group.offset');
    }
`;var ae=["*"];function ie(e,a){if(e&1&&(C(0,"span",3),$(1),_()),e&2){let t=r();m(t.cx("label")),o("pBind",t.ptm("label")),M(),H(t.label)}}function ne(e,a){if(e&1&&O(0,"span",5),e&2){let t=r(2);m(t.icon),o("pBind",t.ptm("icon"))("ngClass",t.cx("icon"))}}function oe(e,a){if(e&1&&f(0,ne,1,4,"span",4),e&2){let t=r(),n=S(5);o("ngIf",t.icon)("ngIfElse",n)}}function re(e,a){if(e&1){let t=j();C(0,"img",7),F("error",function(i){k(t);let y=r(2);return E(y.imageError(i))}),_()}if(e&2){let t=r(2);o("pBind",t.ptm("image"))("src",t.image,w),x("aria-label",t.ariaLabel)}}function se(e,a){if(e&1&&f(0,re,1,3,"img",6),e&2){let t=r();o("ngIf",t.image)}}var le={root:({instance:e})=>["p-avatar p-component",{"p-avatar-image":e.image!=null,"p-avatar-circle":e.shape==="circle","p-avatar-lg":e.size==="large","p-avatar-xl":e.size==="xlarge"}],label:"p-avatar-label",icon:"p-avatar-icon"},Z=(()=>{class e extends J{name="avatar";style=Y;classes=le;static \u0275fac=(()=>{let t;return function(i){return(t||(t=b(e)))(i||e)}})();static \u0275prov=u({token:e,factory:e.\u0275fac})}return e})();var ee=new T("AVATAR_INSTANCE"),ce=(()=>{class e extends Q{$pcAvatar=g(ee,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=g(p,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}label;icon;image;size="normal";shape="square";styleClass;ariaLabel;ariaLabelledBy;onImageError=new z;_componentStyle=g(Z);imageError(t){this.onImageError.emit(t)}static \u0275fac=(()=>{let t;return function(i){return(t||(t=b(e)))(i||e)}})();static \u0275cmp=B({type:e,selectors:[["p-avatar"]],hostVars:4,hostBindings:function(n,i){n&2&&(x("aria-label",i.ariaLabel)("aria-labelledby",i.ariaLabelledBy),m(i.cn(i.cx("root"),i.styleClass)))},inputs:{label:"label",icon:"icon",image:"image",size:"size",shape:"shape",styleClass:"styleClass",ariaLabel:"ariaLabel",ariaLabelledBy:"ariaLabelledBy"},outputs:{onImageError:"onImageError"},features:[P([Z,{provide:ee,useExisting:e},{provide:K,useExisting:e}]),V([p]),L],ngContentSelectors:ae,decls:6,vars:2,consts:[["iconTemplate",""],["imageTemplate",""],[3,"pBind","class",4,"ngIf","ngIfElse"],[3,"pBind"],[3,"pBind","class","ngClass",4,"ngIf","ngIfElse"],[3,"pBind","ngClass"],[3,"pBind","src","error",4,"ngIf"],[3,"error","pBind","src"]],template:function(n,i){if(n&1&&(U(),R(0),f(1,ie,2,4,"span",2)(2,oe,1,2,"ng-template",null,0,D)(4,se,1,1,"ng-template",null,1,D)),n&2){let y=S(3);M(),o("ngIf",i.label)("ngIfElse",y)}},dependencies:[G,q,W,h,p],encapsulation:2,changeDetection:0})}return e})(),ze=(()=>{class e{static \u0275fac=function(n){return new(n||e)};static \u0275mod=N({type:e});static \u0275inj=I({imports:[ce,h,h]})}return e})();export{X as a,ce as b,ze as c};
