import{a as ht}from"./chunk-5TKOWR4R.js";import{a as je,b as Xe}from"./chunk-NMYEYBQI.js";import{a as ut,b as mt}from"./chunk-F2IPNNRA.js";import{a as Ge,f as pt,g as dt,j as ct}from"./chunk-XO3HGZTM.js";import{b as We,c as ge,d as Ye,f as et,g as tt,h as it,i as nt,j as ot,l as lt,n as at,o as rt,p as _e,q as st}from"./chunk-JVUCT3M2.js";import"./chunk-TQXQUECR.js";import"./chunk-LUTOT2G5.js";import{a as ze,b as ue,d as Ne,j as me,k as M,l as he,o as He,p as $e,r as Ue,s as Ze,t as Je}from"./chunk-IETZYUY4.js";import{N as Oe,Q as j,R as N,S as H,U as Se,fa as Ee,ga as Pe,ja as de,ka as $,la as Re,ta as ce,u as pe,v as P}from"./chunk-S22TW3MZ.js";import{a as Ke,d as Qe,i as qe}from"./chunk-ZZWOATJC.js";import{b as Le,c as Fe,d as Be,g as De,h as re,k as se}from"./chunk-LXXOYOJP.js";import"./chunk-4O3FVBGX.js";import{$ as X,$b as W,Ab as r,Bb as c,Bc as le,Cb as d,Db as E,Ec as ae,Hb as A,Ib as L,Jb as S,Kb as T,Lc as _,Mc as z,Pb as b,Qb as s,Ta as p,Tb as I,Ub as k,Vb as f,Wb as y,X as Z,Y as J,Ya as C,Z as be,Za as ke,Zb as xe,_b as Me,ac as Q,ba as O,bc as g,cc as v,db as we,dc as Ce,ec as Ie,ga as u,gc as F,ha as m,hc as B,ia as G,ib as K,ic as D,jb as ve,jc as q,kc as Ae,lc as V,mb as ee,mc as oe,nb as te,nc as Te,ob as h,pa as Y,ua as U,ub as w,vb as ie,wb as ne,wc as R}from"./chunk-XBUTH57D.js";var gt=`
    .p-toggleswitch {
        display: inline-block;
        width: dt('toggleswitch.width');
        height: dt('toggleswitch.height');
    }

    .p-toggleswitch-input {
        cursor: pointer;
        appearance: none;
        position: absolute;
        top: 0;
        inset-inline-start: 0;
        width: 100%;
        height: 100%;
        padding: 0;
        margin: 0;
        opacity: 0;
        z-index: 1;
        outline: 0 none;
        border-radius: dt('toggleswitch.border.radius');
    }

    .p-toggleswitch-slider {
        cursor: pointer;
        width: 100%;
        height: 100%;
        border-width: dt('toggleswitch.border.width');
        border-style: solid;
        border-color: dt('toggleswitch.border.color');
        background: dt('toggleswitch.background');
        transition:
            background dt('toggleswitch.transition.duration'),
            color dt('toggleswitch.transition.duration'),
            border-color dt('toggleswitch.transition.duration'),
            outline-color dt('toggleswitch.transition.duration'),
            box-shadow dt('toggleswitch.transition.duration');
        border-radius: dt('toggleswitch.border.radius');
        outline-color: transparent;
        box-shadow: dt('toggleswitch.shadow');
    }

    .p-toggleswitch-handle {
        position: absolute;
        top: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        background: dt('toggleswitch.handle.background');
        color: dt('toggleswitch.handle.color');
        width: dt('toggleswitch.handle.size');
        height: dt('toggleswitch.handle.size');
        inset-inline-start: dt('toggleswitch.gap');
        margin-block-start: calc(-1 * calc(dt('toggleswitch.handle.size') / 2));
        border-radius: dt('toggleswitch.handle.border.radius');
        transition:
            background dt('toggleswitch.transition.duration'),
            color dt('toggleswitch.transition.duration'),
            inset-inline-start dt('toggleswitch.slide.duration'),
            box-shadow dt('toggleswitch.slide.duration');
    }

    .p-toggleswitch.p-toggleswitch-checked .p-toggleswitch-slider {
        background: dt('toggleswitch.checked.background');
        border-color: dt('toggleswitch.checked.border.color');
    }

    .p-toggleswitch.p-toggleswitch-checked .p-toggleswitch-handle {
        background: dt('toggleswitch.handle.checked.background');
        color: dt('toggleswitch.handle.checked.color');
        inset-inline-start: calc(dt('toggleswitch.width') - calc(dt('toggleswitch.handle.size') + dt('toggleswitch.gap')));
    }

    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover) .p-toggleswitch-slider {
        background: dt('toggleswitch.hover.background');
        border-color: dt('toggleswitch.hover.border.color');
    }

    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover) .p-toggleswitch-handle {
        background: dt('toggleswitch.handle.hover.background');
        color: dt('toggleswitch.handle.hover.color');
    }

    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover).p-toggleswitch-checked .p-toggleswitch-slider {
        background: dt('toggleswitch.checked.hover.background');
        border-color: dt('toggleswitch.checked.hover.border.color');
    }

    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover).p-toggleswitch-checked .p-toggleswitch-handle {
        background: dt('toggleswitch.handle.checked.hover.background');
        color: dt('toggleswitch.handle.checked.hover.color');
    }

    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:focus-visible) .p-toggleswitch-slider {
        box-shadow: dt('toggleswitch.focus.ring.shadow');
        outline: dt('toggleswitch.focus.ring.width') dt('toggleswitch.focus.ring.style') dt('toggleswitch.focus.ring.color');
        outline-offset: dt('toggleswitch.focus.ring.offset');
    }

    .p-toggleswitch.p-invalid > .p-toggleswitch-slider {
        border-color: dt('toggleswitch.invalid.border.color');
    }

    .p-toggleswitch.p-disabled {
        opacity: 1;
    }

    .p-toggleswitch.p-disabled .p-toggleswitch-slider {
        background: dt('toggleswitch.disabled.background');
    }

    .p-toggleswitch.p-disabled .p-toggleswitch-handle {
        background: dt('toggleswitch.handle.disabled.background');
    }
`;var Et=["handle"],Vt=["input"],kt=n=>({checked:n});function Mt(n,a){n&1&&S(0)}function At(n,a){if(n&1&&h(0,Mt,1,0,"ng-container",3),n&2){let e=s();r("ngTemplateOutlet",e.handleTemplate||e._handleTemplate)("ngTemplateOutletContext",V(2,kt,e.checked()))}}var Lt=`
    ${gt}

    p-toggleswitch.ng-invalid.ng-dirty > .p-toggleswitch-slider {
        border-color: dt('toggleswitch.invalid.border.color');
    }
`,Ft={root:{position:"relative"}},Bt={root:({instance:n})=>["p-toggleswitch p-component",{"p-toggleswitch p-component":!0,"p-toggleswitch-checked":n.checked(),"p-disabled":n.$disabled(),"p-invalid":n.invalid()}],input:"p-toggleswitch-input",slider:"p-toggleswitch-slider",handle:"p-toggleswitch-handle"},_t=(()=>{class n extends ce{name="toggleswitch";style=Lt;classes=Bt;inlineStyles=Ft;static \u0275fac=(()=>{let e;return function(i){return(e||(e=U(n)))(i||n)}})();static \u0275prov=J({token:n,factory:n.\u0275fac})}return n})();var ft=new X("TOGGLESWITCH_INSTANCE"),Dt={provide:ge,useExisting:Z(()=>Ve),multi:!0},Ve=(()=>{class n extends at{$pcToggleSwitch=O(ft,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=O(M,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}styleClass;tabindex;inputId;readonly;trueValue=!0;falseValue=!1;ariaLabel;size=ae();ariaLabelledBy;autofocus;onChange=new C;input;handleTemplate;_handleTemplate;focused=!1;_componentStyle=O(_t);templates;onHostClick(e){this.onClick(e)}onAfterContentInit(){this.templates.forEach(e=>{switch(e.getType()){case"handle":this._handleTemplate=e.template;break;default:this._handleTemplate=e.template;break}})}onClick(e){!this.$disabled()&&!this.readonly&&(this.writeModelValue(this.checked()?this.falseValue:this.trueValue),this.onModelChange(this.modelValue()),this.onChange.emit({originalEvent:e,checked:this.modelValue()}),this.input.nativeElement.focus())}onFocus(){this.focused=!0}onBlur(){this.focused=!1,this.onModelTouched()}checked(){return this.modelValue()===this.trueValue}writeControlValue(e,t){t(e),this.cd.markForCheck()}static \u0275fac=(()=>{let e;return function(i){return(e||(e=U(n)))(i||n)}})();static \u0275cmp=K({type:n,selectors:[["p-toggleswitch"],["p-toggleSwitch"],["p-toggle-switch"]],contentQueries:function(t,i,o){if(t&1&&(I(o,Et,4),I(o,de,4)),t&2){let l;f(l=y())&&(i.handleTemplate=l.first),f(l=y())&&(i.templates=l)}},viewQuery:function(t,i){if(t&1&&k(Vt,5),t&2){let o;f(o=y())&&(i.input=o.first)}},hostVars:5,hostBindings:function(t,i){t&1&&b("click",function(l){return i.onHostClick(l)}),t&2&&(w("data-pc-name","toggleswitch"),Q(i.sx("root")),g(i.cn(i.cx("root"),i.styleClass)))},inputs:{styleClass:"styleClass",tabindex:[2,"tabindex","tabindex",z],inputId:"inputId",readonly:[2,"readonly","readonly",_],trueValue:"trueValue",falseValue:"falseValue",ariaLabel:"ariaLabel",size:[1,"size"],ariaLabelledBy:"ariaLabelledBy",autofocus:[2,"autofocus","autofocus",_]},outputs:{onChange:"onChange"},features:[q([Dt,_t,{provide:ft,useExisting:n},{provide:ue,useExisting:n}]),te([M]),ee],decls:5,vars:20,consts:[["input",""],["type","checkbox","role","switch",3,"focus","blur","checked","pAutoFocus","pBind"],[3,"pBind"],[4,"ngTemplateOutlet","ngTemplateOutletContext"]],template:function(t,i){if(t&1){let o=T();c(0,"input",1,0),b("focus",function(){return u(o),m(i.onFocus())})("blur",function(){return u(o),m(i.onBlur())}),d(),c(2,"div",2)(3,"div",2),ie(4,At,1,4,"ng-container"),d()()}t&2&&(g(i.cx("input")),r("checked",i.checked())("pAutoFocus",i.autofocus)("pBind",i.ptm("input")),w("id",i.inputId)("required",i.required()?"":void 0)("disabled",i.$disabled()?"":void 0)("aria-checked",i.checked())("aria-labelledby",i.ariaLabelledBy)("aria-label",i.ariaLabel)("name",i.name())("tabindex",i.tabindex),p(2),g(i.cx("slider")),r("pBind",i.ptm("slider")),p(),g(i.cx("handle")),r("pBind",i.ptm("handle")),p(),ne(i.handleTemplate||i._handleTemplate?4:-1))},dependencies:[se,re,me,$,he,M],encapsulation:2,changeDetection:0})}return n})();var bt=`
    .p-autocomplete {
        display: inline-flex;
    }

    .p-autocomplete-loader {
        position: absolute;
        top: 50%;
        margin-top: -0.5rem;
        inset-inline-end: dt('autocomplete.padding.x');
    }

    .p-autocomplete:has(.p-autocomplete-dropdown) .p-autocomplete-loader {
        inset-inline-end: calc(dt('autocomplete.dropdown.width') + dt('autocomplete.padding.x'));
    }

    .p-autocomplete:has(.p-autocomplete-dropdown) .p-autocomplete-input {
        flex: 1 1 auto;
        width: 1%;
    }

    .p-autocomplete:has(.p-autocomplete-dropdown) .p-autocomplete-input,
    .p-autocomplete:has(.p-autocomplete-dropdown) .p-autocomplete-input-multiple {
        border-start-end-radius: 0;
        border-end-end-radius: 0;
    }

    .p-autocomplete-dropdown {
        cursor: pointer;
        display: inline-flex;
        user-select: none;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        position: relative;
        width: dt('autocomplete.dropdown.width');
        border-start-end-radius: dt('autocomplete.dropdown.border.radius');
        border-end-end-radius: dt('autocomplete.dropdown.border.radius');
        background: dt('autocomplete.dropdown.background');
        border: 1px solid dt('autocomplete.dropdown.border.color');
        border-inline-start: 0 none;
        color: dt('autocomplete.dropdown.color');
        transition:
            background dt('autocomplete.transition.duration'),
            color dt('autocomplete.transition.duration'),
            border-color dt('autocomplete.transition.duration'),
            outline-color dt('autocomplete.transition.duration'),
            box-shadow dt('autocomplete.transition.duration');
        outline-color: transparent;
    }

    .p-autocomplete-dropdown:not(:disabled):hover {
        background: dt('autocomplete.dropdown.hover.background');
        border-color: dt('autocomplete.dropdown.hover.border.color');
        color: dt('autocomplete.dropdown.hover.color');
    }

    .p-autocomplete-dropdown:not(:disabled):active {
        background: dt('autocomplete.dropdown.active.background');
        border-color: dt('autocomplete.dropdown.active.border.color');
        color: dt('autocomplete.dropdown.active.color');
    }

    .p-autocomplete-dropdown:focus-visible {
        box-shadow: dt('autocomplete.dropdown.focus.ring.shadow');
        outline: dt('autocomplete.dropdown.focus.ring.width') dt('autocomplete.dropdown.focus.ring.style') dt('autocomplete.dropdown.focus.ring.color');
        outline-offset: dt('autocomplete.dropdown.focus.ring.offset');
    }

    .p-autocomplete-overlay {
        position: absolute;
        top: 0;
        left: 0;
        background: dt('autocomplete.overlay.background');
        color: dt('autocomplete.overlay.color');
        border: 1px solid dt('autocomplete.overlay.border.color');
        border-radius: dt('autocomplete.overlay.border.radius');
        box-shadow: dt('autocomplete.overlay.shadow');
        min-width: 100%;
    }

    .p-autocomplete-list-container {
        overflow: auto;
    }

    .p-autocomplete-list {
        margin: 0;
        list-style-type: none;
        display: flex;
        flex-direction: column;
        gap: dt('autocomplete.list.gap');
        padding: dt('autocomplete.list.padding');
    }

    .p-autocomplete-option {
        cursor: pointer;
        white-space: nowrap;
        position: relative;
        overflow: hidden;
        display: flex;
        align-items: center;
        padding: dt('autocomplete.option.padding');
        border: 0 none;
        color: dt('autocomplete.option.color');
        background: transparent;
        transition:
            background dt('autocomplete.transition.duration'),
            color dt('autocomplete.transition.duration'),
            border-color dt('autocomplete.transition.duration');
        border-radius: dt('autocomplete.option.border.radius');
    }

    .p-autocomplete-option:not(.p-autocomplete-option-selected):not(.p-disabled).p-focus {
        background: dt('autocomplete.option.focus.background');
        color: dt('autocomplete.option.focus.color');
    }

    .p-autocomplete-option-selected {
        background: dt('autocomplete.option.selected.background');
        color: dt('autocomplete.option.selected.color');
    }

    .p-autocomplete-option-selected.p-focus {
        background: dt('autocomplete.option.selected.focus.background');
        color: dt('autocomplete.option.selected.focus.color');
    }

    .p-autocomplete-option-group {
        margin: 0;
        padding: dt('autocomplete.option.group.padding');
        color: dt('autocomplete.option.group.color');
        background: dt('autocomplete.option.group.background');
        font-weight: dt('autocomplete.option.group.font.weight');
    }

    .p-autocomplete-input-multiple {
        margin: 0;
        list-style-type: none;
        cursor: text;
        overflow: hidden;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        padding: calc(dt('autocomplete.padding.y') / 2) dt('autocomplete.padding.x');
        gap: calc(dt('autocomplete.padding.y') / 2);
        color: dt('autocomplete.color');
        background: dt('autocomplete.background');
        border: 1px solid dt('autocomplete.border.color');
        border-radius: dt('autocomplete.border.radius');
        width: 100%;
        transition:
            background dt('autocomplete.transition.duration'),
            color dt('autocomplete.transition.duration'),
            border-color dt('autocomplete.transition.duration'),
            outline-color dt('autocomplete.transition.duration'),
            box-shadow dt('autocomplete.transition.duration');
        outline-color: transparent;
        box-shadow: dt('autocomplete.shadow');
    }

    .p-autocomplete-input-multiple.p-disabled {
        opacity: 1;
        background: dt('inputtext.disabled.background');
        color: dt('inputtext.disabled.color');
    }

    .p-autocomplete-input-multiple:not(.p-disabled):hover {
        border-color: dt('autocomplete.hover.border.color');
    }

    .p-autocomplete.p-focus .p-autocomplete-input-multiple:not(.p-disabled) {
        border-color: dt('autocomplete.focus.border.color');
        box-shadow: dt('autocomplete.focus.ring.shadow');
        outline: dt('autocomplete.focus.ring.width') dt('autocomplete.focus.ring.style') dt('autocomplete.focus.ring.color');
        outline-offset: dt('autocomplete.focus.ring.offset');
    }

    .p-autocomplete.p-invalid .p-autocomplete-input-multiple {
        border-color: dt('autocomplete.invalid.border.color');
    }

    .p-variant-filled.p-autocomplete-input-multiple {
        background: dt('autocomplete.filled.background');
    }

    .p-autocomplete-input-multiple.p-variant-filled:not(.p-disabled):hover {
        background: dt('autocomplete.filled.hover.background');
    }

    .p-autocomplete.p-focus .p-autocomplete-input-multiple.p-variant-filled:not(.p-disabled) {
        background: dt('autocomplete.filled.focus.background');
    }

    .p-autocomplete-chip.p-chip {
        padding-block-start: calc(dt('autocomplete.padding.y') / 2);
        padding-block-end: calc(dt('autocomplete.padding.y') / 2);
        border-radius: dt('autocomplete.chip.border.radius');
    }

    .p-autocomplete-input-multiple:has(.p-autocomplete-chip) {
        padding-inline-start: calc(dt('autocomplete.padding.y') / 2);
        padding-inline-end: calc(dt('autocomplete.padding.y') / 2);
    }

    .p-autocomplete-chip-item.p-focus .p-autocomplete-chip {
        background: dt('autocomplete.chip.focus.background');
        color: dt('autocomplete.chip.focus.color');
    }

    .p-autocomplete-input-chip {
        flex: 1 1 auto;
        display: inline-flex;
        padding-block-start: calc(dt('autocomplete.padding.y') / 2);
        padding-block-end: calc(dt('autocomplete.padding.y') / 2);
    }

    .p-autocomplete-input-chip input {
        border: 0 none;
        outline: 0 none;
        background: transparent;
        margin: 0;
        padding: 0;
        box-shadow: none;
        border-radius: 0;
        width: 100%;
        font-family: inherit;
        font-feature-settings: inherit;
        font-size: 1rem;
        color: inherit;
    }

    .p-autocomplete-input-chip input::placeholder {
        color: dt('autocomplete.placeholder.color');
    }

    .p-autocomplete.p-invalid .p-autocomplete-input-chip input::placeholder {
        color: dt('autocomplete.invalid.placeholder.color');
    }

    .p-autocomplete-empty-message {
        padding: dt('autocomplete.empty.message.padding');
    }

    .p-autocomplete-fluid {
        display: flex;
    }

    .p-autocomplete-fluid:has(.p-autocomplete-dropdown) .p-autocomplete-input {
        width: 1%;
    }

    .p-autocomplete:has(.p-inputtext-sm) .p-autocomplete-dropdown {
        width: dt('autocomplete.dropdown.sm.width');
    }

    .p-autocomplete:has(.p-inputtext-sm) .p-autocomplete-dropdown .p-icon {
        font-size: dt('form.field.sm.font.size');
        width: dt('form.field.sm.font.size');
        height: dt('form.field.sm.font.size');
    }

    .p-autocomplete:has(.p-inputtext-lg) .p-autocomplete-dropdown {
        width: dt('autocomplete.dropdown.lg.width');
    }

    .p-autocomplete:has(.p-inputtext-lg) .p-autocomplete-dropdown .p-icon {
        font-size: dt('form.field.lg.font.size');
        width: dt('form.field.lg.font.size');
        height: dt('form.field.lg.font.size');
    }

    .p-autocomplete-clear-icon {
        position: absolute;
        top: 50%;
        margin-top: -0.5rem;
        cursor: pointer;
        color: dt('form.field.icon.color');
        inset-inline-end: dt('autocomplete.padding.x');
    }

    .p-autocomplete:has(.p-autocomplete-dropdown) .p-autocomplete-clear-icon {
        inset-inline-end: calc(dt('autocomplete.padding.x') + dt('autocomplete.dropdown.width'));
    }

    .p-autocomplete:has(.p-autocomplete-clear-icon) .p-autocomplete-input {
        padding-inline-end: calc((dt('form.field.padding.x') * 2) + dt('icon.size'));
    }

    .p-inputgroup .p-autocomplete-dropdown {
        border-radius: 0;
    }

    .p-inputgroup > .p-autocomplete:last-child:has(.p-autocomplete-dropdown) > .p-autocomplete-input {
        border-start-end-radius: 0;
        border-end-end-radius: 0;
    }

    .p-inputgroup > .p-autocomplete:last-child .p-autocomplete-dropdown {
        border-start-end-radius: dt('autocomplete.dropdown.border.radius');
        border-end-end-radius: dt('autocomplete.dropdown.border.radius');
    }
`;var zt=["item"],Pt=["empty"],Rt=["header"],Kt=["footer"],Qt=["selecteditem"],qt=["group"],Nt=["loader"],Ht=["removeicon"],$t=["loadingicon"],Gt=["clearicon"],Ut=["dropdownicon"],Wt=["focusInput"],jt=["multiIn"],Zt=["multiContainer"],Jt=["ddBtn"],Xt=["items"],Yt=["scroller"],ei=["overlay"],ti=n=>({i:n}),xt=n=>({$implicit:n}),ii=(n,a,e)=>({removeCallback:n,index:a,class:e}),fe=n=>({height:n}),Ct=(n,a)=>({$implicit:n,options:a}),ni=n=>({options:n}),oi=()=>({}),li=(n,a,e)=>({option:n,i:a,scrollerOptions:e}),ai=(n,a)=>({$implicit:n,index:a});function ri(n,a){if(n&1){let e=T();c(0,"input",18,2),b("input",function(i){u(e);let o=s();return m(o.onInput(i))})("keydown",function(i){u(e);let o=s();return m(o.onKeyDown(i))})("change",function(i){u(e);let o=s();return m(o.onInputChange(i))})("focus",function(i){u(e);let o=s();return m(o.onInputFocus(i))})("blur",function(i){u(e);let o=s();return m(o.onInputBlur(i))})("paste",function(i){u(e);let o=s();return m(o.onInputPaste(i))})("keyup",function(i){u(e);let o=s();return m(o.onInputKeyUp(i))}),d()}if(n&2){let e=s();g(e.cn(e.cx("pcInputText"),e.inputStyleClass)),r("pAutoFocus",e.autofocus)("pt",e.ptm("pcInputText"))("ngStyle",e.inputStyle)("variant",e.$variant())("invalid",e.invalid())("pSize",e.size())("fluid",e.hasFluid),w("type",e.type)("value",e.inputValue())("id",e.inputId)("autocomplete",e.autocomplete)("placeholder",e.placeholder)("name",e.name())("minlength",e.minlength())("min",e.min())("max",e.max())("pattern",e.pattern())("size",e.inputSize())("maxlength",e.maxlength())("tabindex",e.$disabled()?-1:e.tabindex)("required",e.required()?"":void 0)("readonly",e.readonly?"":void 0)("disabled",e.$disabled()?"":void 0)("aria-label",e.ariaLabel)("aria-labelledby",e.ariaLabelledBy)("aria-required",e.required())("aria-expanded",e.overlayVisible??!1)("aria-controls",e.overlayVisible?e.id+"_list":null)("aria-activedescendant",e.focused?e.focusedOptionId:void 0)}}function si(n,a){if(n&1){let e=T();G(),c(0,"svg",21),b("click",function(){u(e);let i=s(2);return m(i.clear())}),d()}if(n&2){let e=s(2);g(e.cx("clearIcon")),r("pBind",e.ptm("clearIcon")),w("aria-hidden",!0)}}function pi(n,a){}function di(n,a){n&1&&h(0,pi,0,0,"ng-template")}function ci(n,a){if(n&1){let e=T();c(0,"span",22),b("click",function(){u(e);let i=s(2);return m(i.clear())}),h(1,di,1,0,null,23),d()}if(n&2){let e=s(2);g(e.cx("clearIcon")),r("pBind",e.ptm("clearIcon")),w("aria-hidden",!0),p(),r("ngTemplateOutlet",e.clearIconTemplate||e._clearIconTemplate)}}function ui(n,a){if(n&1&&(A(0),h(1,si,1,4,"svg",19)(2,ci,2,5,"span",20),L()),n&2){let e=s();p(),r("ngIf",!e.clearIconTemplate&&!e._clearIconTemplate),p(),r("ngIf",e.clearIconTemplate||e._clearIconTemplate)}}function mi(n,a){n&1&&S(0)}function hi(n,a){if(n&1){let e=T();c(0,"span",22),b("click",function(i){u(e);let o=s(2).index,l=s(2);return m(!l.readonly&&!l.$disabled()?l.removeOption(i,o):"")}),G(),E(1,"svg",31),d()}if(n&2){let e=s(4);g(e.cx("chipIcon")),r("pBind",e.ptm("chipIcon")),p(),g(e.cx("chipIcon")),w("aria-hidden",!0)}}function gi(n,a){}function _i(n,a){n&1&&h(0,gi,0,0,"ng-template")}function fi(n,a){if(n&1&&(c(0,"span",32),h(1,_i,1,0,null,29),d()),n&2){let e=s(2).index,t=s(2);r("pBind",t.ptm("chipIcon")),w("aria-hidden",!0),p(),r("ngTemplateOutlet",t.removeIconTemplate||t._removeIconTemplate)("ngTemplateOutletContext",Te(4,ii,t.removeOption.bind(t),e,t.cx("chipIcon")))}}function yi(n,a){if(n&1&&h(0,hi,2,6,"span",20)(1,fi,2,8,"span",30),n&2){let e=s(3);r("ngIf",!e.removeIconTemplate&&!e._removeIconTemplate),p(),r("ngIf",e.removeIconTemplate||e._removeIconTemplate)}}function bi(n,a){if(n&1){let e=T();c(0,"li",26,5)(2,"p-chip",28),b("onRemove",function(i){let o=u(e).index,l=s(2);return m(l.readonly?"":l.removeOption(i,o))}),h(3,mi,1,0,"ng-container",29)(4,yi,2,2,"ng-template",null,6,R),d()()}if(n&2){let e=a.$implicit,t=a.index,i=s(2);g(i.cx("chipItem",V(16,ti,t))),r("pBind",i.ptm("chipItem")),w("id",i.id+"_multiple_option_"+t)("aria-label",i.getOptionLabel(e))("aria-setsize",i.modelValue().length)("aria-posinset",t+1)("aria-selected",!0),p(2),g(i.cx("pcChip")),r("pt",i.ptm("pcChip"))("label",!i.selectedItemTemplate&&!i._selectedItemTemplate&&i.getOptionLabel(e))("disabled",i.$disabled())("removable",!0),p(),r("ngTemplateOutlet",i.selectedItemTemplate||i._selectedItemTemplate)("ngTemplateOutletContext",V(18,xt,e))}}function wi(n,a){if(n&1){let e=T();c(0,"ul",24,3),b("focus",function(i){u(e);let o=s();return m(o.onMultipleContainerFocus(i))})("blur",function(i){u(e);let o=s();return m(o.onMultipleContainerBlur(i))})("keydown",function(i){u(e);let o=s();return m(o.onMultipleContainerKeyDown(i))}),h(2,bi,6,20,"li",25),c(3,"li",26)(4,"input",27,4),b("input",function(i){u(e);let o=s();return m(o.onInput(i))})("keydown",function(i){u(e);let o=s();return m(o.onKeyDown(i))})("change",function(i){u(e);let o=s();return m(o.onInputChange(i))})("focus",function(i){u(e);let o=s();return m(o.onInputFocus(i))})("blur",function(i){u(e);let o=s();return m(o.onInputBlur(i))})("paste",function(i){u(e);let o=s();return m(o.onInputPaste(i))})("keyup",function(i){u(e);let o=s();return m(o.onInputKeyUp(i))}),d()()()}if(n&2){let e=s();g(e.cx("inputMultiple")),r("pBind",e.ptm("inputMultiple"))("tabindex",-1),w("aria-orientation","horizontal")("aria-activedescendant",e.focused?e.focusedMultipleOptionId:void 0),p(2),r("ngForOf",e.modelValue()),p(),g(e.cx("inputChip")),r("pBind",e.ptm("inputChip")),p(),g(e.cx("pcInputText")),r("pAutoFocus",e.autofocus)("pBind",e.ptm("input"))("ngStyle",e.inputStyle),w("type",e.type)("id",e.inputId)("autocomplete",e.autocomplete)("name",e.name())("minlength",e.minlength())("maxlength",e.maxlength())("size",e.size())("min",e.min())("max",e.max())("pattern",e.pattern())("placeholder",e.$filled()?null:e.placeholder)("tabindex",e.$disabled()?-1:e.tabindex)("required",e.required()?"":void 0)("readonly",e.readonly?"":void 0)("disabled",e.$disabled()?"":void 0)("aria-label",e.ariaLabel)("aria-labelledby",e.ariaLabelledBy)("aria-required",e.required())("aria-expanded",e.overlayVisible??!1)("aria-controls",e.overlayVisible?e.id+"_list":null)("aria-activedescendant",e.focused?e.focusedOptionId:void 0)}}function vi(n,a){if(n&1&&(G(),E(0,"svg",35)),n&2){let e=s(2);g(e.cx("loader")),r("pBind",e.ptm("loader"))("spin",!0),w("aria-hidden",!0)}}function xi(n,a){}function Ci(n,a){n&1&&h(0,xi,0,0,"ng-template")}function Ii(n,a){if(n&1&&(c(0,"span",32),h(1,Ci,1,0,null,23),d()),n&2){let e=s(2);g(e.cx("loader")),r("pBind",e.ptm("loader")),w("aria-hidden",!0),p(),r("ngTemplateOutlet",e.loadingIconTemplate||e._loadingIconTemplate)}}function Ti(n,a){if(n&1&&(A(0),h(1,vi,1,5,"svg",33)(2,Ii,2,5,"span",34),L()),n&2){let e=s();p(),r("ngIf",!e.loadingIconTemplate&&!e._loadingIconTemplate),p(),r("ngIf",e.loadingIconTemplate||e._loadingIconTemplate)}}function Oi(n,a){if(n&1&&E(0,"span",38),n&2){let e=s(2);r("ngClass",e.dropdownIcon),w("aria-hidden",!0)}}function Si(n,a){if(n&1&&(G(),E(0,"svg",40)),n&2){let e=s(3);r("pBind",e.ptm("dropdown"))}}function Ei(n,a){}function Vi(n,a){n&1&&h(0,Ei,0,0,"ng-template")}function ki(n,a){if(n&1&&(A(0),h(1,Si,1,1,"svg",39)(2,Vi,1,0,null,23),L()),n&2){let e=s(2);p(),r("ngIf",!e.dropdownIconTemplate&&!e._dropdownIconTemplate),p(),r("ngTemplateOutlet",e.dropdownIconTemplate||e._dropdownIconTemplate)}}function Mi(n,a){if(n&1){let e=T();c(0,"button",36,7),b("click",function(i){u(e);let o=s();return m(o.handleDropdownClick(i))}),h(2,Oi,1,2,"span",37)(3,ki,3,2,"ng-container",14),d()}if(n&2){let e=s();g(e.cx("dropdown")),r("pBind",e.ptm("dropdown"))("disabled",e.$disabled()),w("aria-label",e.dropdownAriaLabel)("tabindex",e.tabindex),p(2),r("ngIf",e.dropdownIcon),p(),r("ngIf",!e.dropdownIcon)}}function Ai(n,a){n&1&&S(0)}function Li(n,a){n&1&&S(0)}function Fi(n,a){if(n&1&&h(0,Li,1,0,"ng-container",29),n&2){let e=a.$implicit,t=a.options;s(2);let i=xe(6);r("ngTemplateOutlet",i)("ngTemplateOutletContext",oe(2,Ct,e,t))}}function Bi(n,a){n&1&&S(0)}function Di(n,a){if(n&1&&h(0,Bi,1,0,"ng-container",29),n&2){let e=a.options,t=s(4);r("ngTemplateOutlet",t.loaderTemplate||t._loaderTemplate)("ngTemplateOutletContext",V(2,ni,e))}}function zi(n,a){n&1&&(A(0),h(1,Di,1,4,"ng-template",null,10,R),L())}function Pi(n,a){if(n&1){let e=T();c(0,"p-scroller",44,9),b("onLazyLoad",function(i){u(e);let o=s(2);return m(o.onLazyLoad.emit(i))}),h(2,Fi,1,5,"ng-template",null,1,R)(4,zi,3,0,"ng-container",14),d()}if(n&2){let e=s(2);Q(V(9,fe,e.scrollHeight)),r("pt",e.ptm("virtualScroller"))("items",e.visibleOptions())("itemSize",e.virtualScrollItemSize)("autoSize",!0)("lazy",e.lazy)("options",e.virtualScrollOptions),p(4),r("ngIf",e.loaderTemplate||e._loaderTemplate)}}function Ri(n,a){n&1&&S(0)}function Ki(n,a){if(n&1&&(A(0),h(1,Ri,1,0,"ng-container",29),L()),n&2){s();let e=xe(6),t=s();p(),r("ngTemplateOutlet",e)("ngTemplateOutletContext",oe(3,Ct,t.visibleOptions(),Ae(2,oi)))}}function Qi(n,a){if(n&1&&(c(0,"span"),v(1),d()),n&2){let e=s(2).$implicit,t=s(3);p(),Ce(t.getOptionGroupLabel(e.optionGroup))}}function qi(n,a){n&1&&S(0)}function Ni(n,a){if(n&1&&(A(0),c(1,"li",48),h(2,Qi,2,1,"span",14)(3,qi,1,0,"ng-container",29),d(),L()),n&2){let e=s(),t=e.$implicit,i=e.index,o=s().options,l=s(2);p(),g(l.cx("optionGroup")),r("pBind",l.ptm("optionGroup"))("ngStyle",V(8,fe,o.itemSize+"px")),w("id",l.id+"_"+l.getOptionIndex(i,o)),p(),r("ngIf",!l.groupTemplate),p(),r("ngTemplateOutlet",l.groupTemplate)("ngTemplateOutletContext",V(10,xt,t.optionGroup))}}function Hi(n,a){if(n&1&&(c(0,"span"),v(1),d()),n&2){let e=s(2).$implicit,t=s(3);p(),Ce(t.getOptionLabel(e))}}function $i(n,a){n&1&&S(0)}function Gi(n,a){if(n&1){let e=T();A(0),c(1,"li",49),b("click",function(i){u(e);let o=s().$implicit,l=s(3);return m(l.onOptionSelect(i,o))})("mouseenter",function(i){u(e);let o=s().index,l=s().options,x=s(2);return m(x.onOptionMouseEnter(i,x.getOptionIndex(o,l)))}),h(2,Hi,2,1,"span",14)(3,$i,1,0,"ng-container",29),d(),L()}if(n&2){let e=s(),t=e.$implicit,i=e.index,o=s().options,l=s(2);p(),g(l.cx("option",Te(14,li,t,i,o))),r("pBind",l.getPTOptions(t,o,i,"option"))("ngStyle",V(18,fe,o.itemSize+"px")),w("id",l.id+"_"+l.getOptionIndex(i,o))("aria-label",l.getOptionLabel(t))("aria-selected",l.isSelected(t))("aria-disabled",l.isOptionDisabled(t))("data-p-focused",l.focusedOptionIndex()===l.getOptionIndex(i,o))("aria-setsize",l.ariaSetSize)("aria-posinset",l.getAriaPosInset(l.getOptionIndex(i,o))),p(),r("ngIf",!l.itemTemplate&&!l._itemTemplate),p(),r("ngTemplateOutlet",l.itemTemplate||l._itemTemplate)("ngTemplateOutletContext",oe(20,ai,t,o.getOptions?o.getOptions(i):i))}}function Ui(n,a){if(n&1&&h(0,Ni,4,12,"ng-container",14)(1,Gi,4,23,"ng-container",14),n&2){let e=a.$implicit,t=s(3);r("ngIf",t.isOptionGroup(e)),p(),r("ngIf",!t.isOptionGroup(e))}}function Wi(n,a){if(n&1&&(A(0),v(1),L()),n&2){let e=s(4);p(),Ie(" ",e.searchResultMessageText," ")}}function ji(n,a){n&1&&S(0,null,12)}function Zi(n,a){if(n&1&&(c(0,"li",48),h(1,Wi,2,1,"ng-container",50)(2,ji,2,0,"ng-container",23),d()),n&2){let e=s().options,t=s(2);g(t.cx("emptyMessage")),r("pBind",t.ptm("emptyMessage"))("ngStyle",V(7,fe,e.itemSize+"px")),p(),r("ngIf",!t.emptyTemplate&&!t._emptyTemplate)("ngIfElse",t.empty),p(),r("ngTemplateOutlet",t.emptyTemplate||t._emptyTemplate)}}function Ji(n,a){if(n&1&&(c(0,"ul",45,11),h(2,Ui,2,2,"ng-template",46)(3,Zi,3,9,"li",47),d()),n&2){let e=a.$implicit,t=a.options,i=s(2);Q(t.contentStyle),g(i.cn(i.cx("list"),t.contentStyleClass)),r("pBind",i.ptm("list")),w("id",i.id+"_list")("aria-label",i.listLabel),p(2),r("ngForOf",e),p(),r("ngIf",!e||e&&e.length===0&&i.showEmptyMessage)}}function Xi(n,a){n&1&&S(0)}function Yi(n,a){if(n&1&&(c(0,"div",41),h(1,Ai,1,0,"ng-container",23),c(2,"div",32),h(3,Pi,5,11,"p-scroller",42)(4,Ki,2,6,"ng-container",14),d(),h(5,Ji,4,9,"ng-template",null,8,R)(7,Xi,1,0,"ng-container",23),d(),c(8,"span",43),v(9),d()),n&2){let e=s();g(e.cn(e.cx("overlay"),e.panelStyleClass)),r("pBind",e.ptm("overlay"))("ngStyle",e.panelStyle),p(),r("ngTemplateOutlet",e.headerTemplate||e._headerTemplate),p(),g(e.cx("listContainer")),Me("max-height",e.virtualScroll?"auto":e.scrollHeight),r("pBind",e.ptm("listContainer")),p(),r("ngIf",e.virtualScroll),p(),r("ngIf",!e.virtualScroll),p(3),r("ngTemplateOutlet",e.footerTemplate||e._footerTemplate),p(2),Ie(" ",e.selectedMessageText," ")}}var en=`
    ${bt}

    /* For PrimeNG */
    p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input,
    p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input-multiple,
    p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input,
    p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input-multiple p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input,
    p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input-multiple {
        border-color: dt('autocomplete.invalid.border.color');
    }

    p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input:enabled:focus,
    p-autoComplete.ng-invalid.ng-dirty:not(.p-disabled).p-focus .p-autocomplete-input-multiple,
    p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input:enabled:focus,
    p-auto-complete.ng-invalid.ng-dirty:not(.p-disabled).p-focus .p-autocomplete-input-multiple,
    p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input:enabled:focus,
    p-autocomplete.ng-invalid.ng-dirty:not(.p-disabled).p-focus .p-autocomplete-input-multiple {
        border-color: dt('autocomplete.focus.border.color');
    }

    p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input-chip input::placeholder,
    p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input-chip input::placeholder,
    p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input-chip input::placeholder {
        color: dt('autocomplete.invalid.placeholder.color');
    }

    p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input::placeholder,
    p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input::placeholder,
    p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input::placeholder {
        color: dt('autocomplete.invalid.placeholder.color');
    }
`,tn={root:{position:"relative"}},nn={root:({instance:n})=>["p-autocomplete p-component p-inputwrapper",{"p-invalid":n.invalid(),"p-focus":n.focused,"p-inputwrapper-filled":n.$filled(),"p-inputwrapper-focus":n.focused&&!n.$disabled()||n.autofocus||n.overlayVisible,"p-autocomplete-open":n.overlayVisible,"p-autocomplete-clearable":n.showClear&&!n.$disabled(),"p-autocomplete-fluid":n.hasFluid}],pcInputText:"p-autocomplete-input",inputMultiple:({instance:n})=>["p-autocomplete-input-multiple",{"p-disabled":n.$disabled(),"p-variant-filled":n.$variant()==="filled"}],chipItem:({instance:n,i:a})=>["p-autocomplete-chip-item",{"p-focus":n.focusedMultipleOptionIndex()===a}],pcChip:"p-autocomplete-chip",chipIcon:"p-autocomplete-chip-icon",inputChip:"p-autocomplete-input-chip",loader:"p-autocomplete-loader",dropdown:"p-autocomplete-dropdown",overlay:({instance:n})=>["p-autocomplete-overlay p-component-overlay p-component",{"p-input-filled":n.$variant()==="filled","p-ripple-disabled":n.config.ripple()===!1}],listContainer:"p-autocomplete-list-container",list:"p-autocomplete-list",optionGroup:"p-autocomplete-option-group",option:({instance:n,option:a,i:e,scrollerOptions:t})=>({"p-autocomplete-option":!0,"p-autocomplete-option-selected":n.isSelected(a),"p-focus":n.focusedOptionIndex()===n.getOptionIndex(e,t),"p-disabled":n.isOptionDisabled(a)}),emptyMessage:"p-autocomplete-empty-message",clearIcon:"p-autocomplete-clear-icon"},wt=(()=>{class n extends ce{name="autocomplete";style=en;classes=nn;inlineStyles=tn;static \u0275fac=(()=>{let e;return function(i){return(e||(e=U(n)))(i||n)}})();static \u0275prov=J({token:n,factory:n.\u0275fac})}return n})();var vt=new X("AUTOCOMPLETE_INSTANCE"),on={provide:ge,useExisting:Z(()=>ye),multi:!0},ye=(()=>{class n extends rt{overlayService;zone;$pcAutoComplete=O(vt,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=O(M,{self:!0});minLength=1;minQueryLength;delay=300;panelStyle;styleClass;panelStyleClass;inputStyle;inputId;inputStyleClass;placeholder;readonly;scrollHeight="200px";lazy=!1;virtualScroll;virtualScrollItemSize;virtualScrollOptions;autoHighlight;forceSelection;type="text";autoZIndex=!0;baseZIndex=0;ariaLabel;dropdownAriaLabel;ariaLabelledBy;dropdownIcon;unique=!0;group;completeOnFocus=!1;showClear=!1;dropdown;showEmptyMessage=!0;dropdownMode="blank";multiple;addOnTab=!1;tabindex;dataKey;emptyMessage;showTransitionOptions=".12s cubic-bezier(0, 0, 0.2, 1)";hideTransitionOptions=".1s linear";autofocus;autocomplete="off";optionGroupChildren="items";optionGroupLabel="label";overlayOptions;get suggestions(){return this._suggestions()}set suggestions(e){this._suggestions.set(e),this.handleSuggestionsChange()}optionLabel;optionValue;id;searchMessage;emptySelectionMessage;selectionMessage;autoOptionFocus=!1;selectOnFocus;searchLocale;optionDisabled;focusOnHover=!0;typeahead=!0;addOnBlur=!1;separator;appendTo=ae(void 0);completeMethod=new C;onSelect=new C;onUnselect=new C;onAdd=new C;onFocus=new C;onBlur=new C;onDropdownClick=new C;onClear=new C;onInputKeydown=new C;onKeyUp=new C;onShow=new C;onHide=new C;onLazyLoad=new C;inputEL;multiInputEl;multiContainerEL;dropdownButton;itemsViewChild;scroller;overlayViewChild;itemsWrapper;itemTemplate;emptyTemplate;headerTemplate;footerTemplate;selectedItemTemplate;groupTemplate;loaderTemplate;removeIconTemplate;loadingIconTemplate;clearIconTemplate;dropdownIconTemplate;onHostClick(e){this.onContainerClick(e)}value;_suggestions=Y(null);timeout;overlayVisible;suggestionsUpdated;highlightOption;highlightOptionChanged;focused=!1;loading;scrollHandler;listId;searchTimeout;dirty=!1;_itemTemplate;_groupTemplate;_selectedItemTemplate;_headerTemplate;_emptyTemplate;_footerTemplate;_loaderTemplate;_removeIconTemplate;_loadingIconTemplate;_clearIconTemplate;_dropdownIconTemplate;focusedMultipleOptionIndex=Y(-1);focusedOptionIndex=Y(-1);_componentStyle=O(wt);$appendTo=le(()=>this.appendTo()||this.config.overlayAppendTo());visibleOptions=le(()=>this.group?this.flatOptions(this._suggestions()):this._suggestions()||[]);inputValue=le(()=>{let e=this.modelValue(),t=this.optionValueSelected?(this.suggestions||[]).find(i=>H(i,e,this.equalityKey())):e;if(j(e))if(typeof e=="object"||this.optionValueSelected){let i=this.getOptionLabel(t);return i??e}else return e;else return""});get focusedMultipleOptionId(){return this.focusedMultipleOptionIndex()!==-1?`${this.id}_multiple_option_${this.focusedMultipleOptionIndex()}`:null}get focusedOptionId(){return this.focusedOptionIndex()!==-1?`${this.id}_${this.focusedOptionIndex()}`:null}get searchResultMessageText(){return j(this.visibleOptions())&&this.overlayVisible?this.searchMessageText.replaceAll("{0}",this.visibleOptions().length):this.emptySearchMessageText}get searchMessageText(){return this.searchMessage||this.config.translation.searchMessage||""}get emptySearchMessageText(){return this.emptyMessage||this.config.translation.emptySearchMessage||""}get selectionMessageText(){return this.selectionMessage||this.config.translation.selectionMessage||""}get emptySelectionMessageText(){return this.emptySelectionMessage||this.config.translation.emptySelectionMessage||""}get selectedMessageText(){return this.hasSelectedOption()?this.selectionMessageText.replaceAll("{0}",this.multiple?this.modelValue()?.length:"1"):this.emptySelectionMessageText}get ariaSetSize(){return this.visibleOptions().filter(e=>!this.isOptionGroup(e)).length}get listLabel(){return this.config.getTranslation(Re.ARIA).listLabel}get virtualScrollerDisabled(){return!this.virtualScroll}get optionValueSelected(){return typeof this.modelValue()=="string"&&this.optionValue}chipItemClass(e){return this._componentStyle.classes.chipItem({instance:this,i:e})}constructor(e,t){super(),this.overlayService=e,this.zone=t}onInit(){this.id=this.id||ze("pn_id_"),this.cd.detectChanges()}templates;onAfterContentInit(){this.templates.forEach(e=>{switch(e.getType()){case"item":this._itemTemplate=e.template;break;case"group":this._groupTemplate=e.template;break;case"selecteditem":this._selectedItemTemplate=e.template;break;case"selectedItem":this._selectedItemTemplate=e.template;break;case"header":this._headerTemplate=e.template;break;case"empty":this._emptyTemplate=e.template;break;case"footer":this._footerTemplate=e.template;break;case"loader":this._loaderTemplate=e.template;break;case"removetokenicon":this._removeIconTemplate=e.template;break;case"loadingicon":this._loadingIconTemplate=e.template;break;case"clearicon":this._clearIconTemplate=e.template;break;case"dropdownicon":this._dropdownIconTemplate=e.template;break;default:this._itemTemplate=e.template;break}})}onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"])),this.suggestionsUpdated&&this.overlayViewChild&&this.zone.runOutsideAngular(()=>{setTimeout(()=>{this.overlayViewChild&&this.overlayViewChild.alignOverlay()},1),this.suggestionsUpdated=!1})}handleSuggestionsChange(){if(this.loading){this._suggestions()?.length>0||this.showEmptyMessage||this.emptyTemplate?this.show():this.hide();let e=this.overlayVisible&&this.autoOptionFocus?this.findFirstFocusedOptionIndex():-1;this.focusedOptionIndex.set(e),this.suggestionsUpdated=!0,this.loading=!1,this.cd.markForCheck()}}flatOptions(e){return(e||[]).reduce((t,i,o)=>{t.push({optionGroup:i,group:!0,index:o});let l=this.getOptionGroupChildren(i);return l&&l.forEach(x=>t.push(x)),t},[])}isOptionGroup(e){return this.optionGroupLabel&&e.optionGroup&&e.group}findFirstOptionIndex(){return this.visibleOptions().findIndex(e=>this.isValidOption(e))}findLastOptionIndex(){return Se(this.visibleOptions(),e=>this.isValidOption(e))}findFirstFocusedOptionIndex(){let e=this.findSelectedOptionIndex();return e<0?this.findFirstOptionIndex():e}findLastFocusedOptionIndex(){let e=this.findSelectedOptionIndex();return e<0?this.findLastOptionIndex():e}findSelectedOptionIndex(){return this.hasSelectedOption()?this.visibleOptions().findIndex(e=>this.isValidSelectedOption(e)):-1}findNextOptionIndex(e){let t=e<this.visibleOptions().length-1?this.visibleOptions().slice(e+1).findIndex(i=>this.isValidOption(i)):-1;return t>-1?t+e+1:e}findPrevOptionIndex(e){let t=e>0?Se(this.visibleOptions().slice(0,e),i=>this.isValidOption(i)):-1;return t>-1?t:e}isValidSelectedOption(e){return this.isValidOption(e)&&this.isSelected(e)}isValidOption(e){return e&&!(this.isOptionDisabled(e)||this.isOptionGroup(e))}isOptionDisabled(e){return this.optionDisabled?N(e,this.optionDisabled):!1}isSelected(e){return this.multiple?this.unique?this.modelValue()?.some(t=>H(t,e,this.equalityKey())):!1:H(this.modelValue(),e,this.equalityKey())}isOptionMatched(e,t){return this.isValidOption(e)&&this.getOptionLabel(e).toLocaleLowerCase(this.searchLocale)===t.toLocaleLowerCase(this.searchLocale)}isInputClicked(e){return e.target===this.inputEL?.nativeElement}isDropdownClicked(e){return this.dropdownButton?.nativeElement?e.target===this.dropdownButton.nativeElement||this.dropdownButton.nativeElement.contains(e.target):!1}equalityKey(){return this.optionValue?void 0:this.dataKey}onContainerClick(e){this.$disabled()||this.loading||this.isInputClicked(e)||this.isDropdownClicked(e)||(!this.overlayViewChild||!this.overlayViewChild.overlayViewChild?.nativeElement.contains(e.target))&&P(this.inputEL?.nativeElement)}handleDropdownClick(e){let t;this.overlayVisible?this.hide(!0):(P(this.inputEL?.nativeElement),t=this.inputEL?.nativeElement?.value,this.dropdownMode==="blank"?this.search(e,"","dropdown"):this.dropdownMode==="current"&&this.search(e,t,"dropdown")),this.onDropdownClick.emit({originalEvent:e,query:t})}onInput(e){if(this.typeahead){let t=this.minQueryLength||this.minLength;this.searchTimeout&&clearTimeout(this.searchTimeout);let i=e.target.value;this.maxlength()!==null&&(i=i.split("").slice(0,this.maxlength()).join("")),!this.multiple&&!this.forceSelection&&this.updateModel(i),i.length===0&&!this.multiple?(this.onClear.emit(),setTimeout(()=>{this.hide()},this.delay/2)):i.length>=t?(this.focusedOptionIndex.set(-1),this.searchTimeout=setTimeout(()=>{this.search(e,i,"input")},this.delay)):this.hide()}}onInputChange(e){if(this.forceSelection){let t=!1;if(this.visibleOptions()){let i=this.visibleOptions().find(o=>this.isOptionMatched(o,this.inputEL?.nativeElement?.value||""));i!==void 0&&(t=!0,!this.isSelected(i)&&this.onOptionSelect(e,i))}t||(this.inputEL?.nativeElement&&(this.inputEL.nativeElement.value=""),!this.multiple&&this.updateModel(null))}}onInputFocus(e){if(this.$disabled())return;!this.dirty&&this.completeOnFocus&&this.search(e,e.target.value,"focus"),this.dirty=!0,this.focused=!0;let t=this.focusedOptionIndex()!==-1?this.focusedOptionIndex():this.overlayVisible&&this.autoOptionFocus?this.findFirstFocusedOptionIndex():-1;this.focusedOptionIndex.set(t),this.overlayVisible&&this.scrollInView(this.focusedOptionIndex()),this.onFocus.emit(e)}onMultipleContainerFocus(e){this.$disabled()||(this.focused=!0)}onMultipleContainerBlur(e){this.focusedMultipleOptionIndex.set(-1),this.focused=!1}onMultipleContainerKeyDown(e){if(this.$disabled()){e.preventDefault();return}switch(e.code){case"ArrowLeft":this.onArrowLeftKeyOnMultiple(e);break;case"ArrowRight":this.onArrowRightKeyOnMultiple(e);break;case"Backspace":this.onBackspaceKeyOnMultiple(e);break;default:break}}onInputBlur(e){if(this.dirty=!1,this.focused=!1,this.focusedOptionIndex.set(-1),this.addOnBlur&&this.multiple&&!this.typeahead){let t=(this.multiInputEl?.nativeElement?.value||e.target.value||"").trim();t&&!this.isSelected(t)&&(this.updateModel([...this.modelValue()||[],t]),this.onAdd.emit({originalEvent:e,value:t}),this.multiInputEl?.nativeElement?this.multiInputEl.nativeElement.value="":e.target.value="")}this.onModelTouched(),this.onBlur.emit(e)}onInputPaste(e){if(this.separator&&this.multiple&&!this.typeahead){let t=(e.clipboardData||window.clipboardData)?.getData("Text");if(t){let i=t.split(this.separator),o=[...this.modelValue()||[]];if(i.forEach(l=>{let x=l.trim();x&&!this.isSelected(x)&&o.push(x)}),o.length>(this.modelValue()||[]).length){let l=o.slice((this.modelValue()||[]).length);this.updateModel(o),l.forEach(x=>{this.onAdd.emit({originalEvent:e,value:x})}),this.multiInputEl?.nativeElement?this.multiInputEl.nativeElement.value="":e.target.value="",e.preventDefault()}}}else this.onKeyDown(e)}onInputKeyUp(e){this.onKeyUp.emit(e)}onKeyDown(e){if(this.$disabled()){e.preventDefault();return}switch(this.onInputKeydown.emit(e),e.code){case"ArrowDown":this.onArrowDownKey(e);break;case"ArrowUp":this.onArrowUpKey(e);break;case"ArrowLeft":this.onArrowLeftKey(e);break;case"ArrowRight":this.onArrowRightKey(e);break;case"Home":this.onHomeKey(e);break;case"End":this.onEndKey(e);break;case"PageDown":this.onPageDownKey(e);break;case"PageUp":this.onPageUpKey(e);break;case"Enter":case"NumpadEnter":this.onEnterKey(e);break;case"Escape":this.onEscapeKey(e);break;case"Tab":this.onTabKey(e);break;case"Backspace":this.onBackspaceKey(e);break;case"ShiftLeft":case"ShiftRight":break;default:this.handleSeparatorKey(e);break}}handleSeparatorKey(e){if(this.separator&&this.multiple&&!this.typeahead&&(this.separator===e.key||typeof this.separator=="string"&&e.key===this.separator||this.separator instanceof RegExp&&e.key.match(this.separator))){let t=(this.multiInputEl?.nativeElement?.value||e.target.value||"").trim();t&&!this.isSelected(t)&&(this.updateModel([...this.modelValue()||[],t]),this.onAdd.emit({originalEvent:e,value:t}),this.multiInputEl?.nativeElement?this.multiInputEl.nativeElement.value="":e.target.value="",e.preventDefault())}}onArrowDownKey(e){if(!this.overlayVisible)return;let t=this.focusedOptionIndex()!==-1?this.findNextOptionIndex(this.focusedOptionIndex()):this.findFirstFocusedOptionIndex();this.changeFocusedOptionIndex(e,t),e.preventDefault(),e.stopPropagation()}onArrowUpKey(e){if(this.overlayVisible)if(e.altKey)this.focusedOptionIndex()!==-1&&this.onOptionSelect(e,this.visibleOptions()[this.focusedOptionIndex()]),this.overlayVisible&&this.hide(),e.preventDefault();else{let t=this.focusedOptionIndex()!==-1?this.findPrevOptionIndex(this.focusedOptionIndex()):this.findLastFocusedOptionIndex();this.changeFocusedOptionIndex(e,t),e.preventDefault(),e.stopPropagation()}}onArrowLeftKey(e){let t=e.currentTarget;this.focusedOptionIndex.set(-1),this.multiple&&(Oe(t.value)&&this.hasSelectedOption()?(P(this.multiContainerEL?.nativeElement),this.focusedMultipleOptionIndex.set(this.modelValue().length)):e.stopPropagation())}onArrowRightKey(e){this.focusedOptionIndex.set(-1),this.multiple&&e.stopPropagation()}onHomeKey(e){let{currentTarget:t}=e,i=t.value.length;t.setSelectionRange(0,e.shiftKey?i:0),this.focusedOptionIndex.set(-1),e.preventDefault()}onEndKey(e){let{currentTarget:t}=e,i=t.value.length;t.setSelectionRange(e.shiftKey?0:i,i),this.focusedOptionIndex.set(-1),e.preventDefault()}onPageDownKey(e){this.scrollInView(this.visibleOptions().length-1),e.preventDefault()}onPageUpKey(e){this.scrollInView(0),e.preventDefault()}onEnterKey(e){if(!this.typeahead&&!this.forceSelection&&this.multiple){let t=e.target.value?.trim();t&&!this.isSelected(t)&&(this.updateModel([...this.modelValue()||[],t]),this.inputEL?.nativeElement&&(this.inputEL.nativeElement.value=""))}if(this.overlayVisible)this.focusedOptionIndex()!==-1&&this.onOptionSelect(e,this.visibleOptions()[this.focusedOptionIndex()]),this.hide();else return;e.preventDefault()}onEscapeKey(e){this.overlayVisible&&this.hide(!0),e.preventDefault()}onTabKey(e){if(this.focusedOptionIndex()!==-1){this.onOptionSelect(e,this.visibleOptions()[this.focusedOptionIndex()]);return}if(this.multiple&&!this.typeahead){let t=(this.multiInputEl?.nativeElement?.value||this.inputEL?.nativeElement?.value||"").trim();if(this.addOnTab&&t&&!this.isSelected(t)){this.updateModel([...this.modelValue()||[],t]),this.onAdd.emit({originalEvent:e,value:t}),this.multiInputEl?.nativeElement?this.multiInputEl.nativeElement.value="":this.inputEL?.nativeElement&&(this.inputEL.nativeElement.value=""),this.updateInputValue(),e.preventDefault(),this.overlayVisible&&this.hide();return}}this.overlayVisible&&this.hide()}onBackspaceKey(e){if(this.multiple){if(j(this.modelValue())&&!this.inputEL?.nativeElement?.value){let t=this.modelValue()[this.modelValue().length-1],i=this.modelValue().slice(0,-1);this.updateModel(i),this.onUnselect.emit({originalEvent:e,value:t})}e.stopPropagation()}}onArrowLeftKeyOnMultiple(e){let t=this.focusedMultipleOptionIndex()<1?0:this.focusedMultipleOptionIndex()-1;this.focusedMultipleOptionIndex.set(t)}onArrowRightKeyOnMultiple(e){let t=this.focusedMultipleOptionIndex();t++,this.focusedMultipleOptionIndex.set(t),t>this.modelValue().length-1&&(this.focusedMultipleOptionIndex.set(-1),P(this.inputEL?.nativeElement))}onBackspaceKeyOnMultiple(e){this.focusedMultipleOptionIndex()!==-1&&this.removeOption(e,this.focusedMultipleOptionIndex())}onOptionSelect(e,t,i=!0){this.multiple?(this.inputEL?.nativeElement&&(this.inputEL.nativeElement.value=""),this.isSelected(t)||this.updateModel([...this.modelValue()||[],t])):this.updateModel(t),this.onSelect.emit({originalEvent:e,value:t}),i&&this.hide(!0)}onOptionMouseEnter(e,t){this.focusOnHover&&this.changeFocusedOptionIndex(e,t)}search(e,t,i){t!=null&&(i==="input"&&t.trim().length===0||(this.loading=!0,this.completeMethod.emit({originalEvent:e,query:t})))}removeOption(e,t){e.stopPropagation();let i=this.modelValue()[t],o=this.modelValue().filter((l,x)=>x!==t);this.updateModel(o),this.onUnselect.emit({originalEvent:e,value:i}),P(this.inputEL?.nativeElement)}updateModel(e){let t=this.multiple?e.map(i=>this.getOptionValue(i)):this.getOptionValue(e);this.value=t,this.writeModelValue(e),this.onModelChange(t),this.updateInputValue(),this.cd.markForCheck()}updateInputValue(){this.inputEL&&this.inputEL.nativeElement&&(this.multiple?this.inputEL.nativeElement.value="":this.inputEL.nativeElement.value=this.inputValue())}autoUpdateModel(){if((this.selectOnFocus||this.autoHighlight)&&this.autoOptionFocus&&!this.hasSelectedOption()){let e=this.findFirstFocusedOptionIndex();this.focusedOptionIndex.set(e),this.onOptionSelect(null,this.visibleOptions()[this.focusedOptionIndex()],!1)}}scrollInView(e=-1){let t=e!==-1?`${this.id}_${e}`:this.focusedOptionId;if(this.itemsViewChild&&this.itemsViewChild.nativeElement){let i=pe(this.itemsViewChild.nativeElement,`li[id="${t}"]`);i?i.scrollIntoView&&i.scrollIntoView({block:"nearest",inline:"nearest"}):this.virtualScrollerDisabled||setTimeout(()=>{this.virtualScroll&&this.scroller?.scrollToIndex(e!==-1?e:this.focusedOptionIndex())},0)}}changeFocusedOptionIndex(e,t){this.focusedOptionIndex()!==t&&(this.focusedOptionIndex.set(t),this.scrollInView(),this.selectOnFocus&&this.onOptionSelect(e,this.visibleOptions()[t],!1))}show(e=!1){this.dirty=!0,this.overlayVisible=!0;let t=this.focusedOptionIndex()!==-1?this.focusedOptionIndex():this.autoOptionFocus?this.findFirstFocusedOptionIndex():-1;this.focusedOptionIndex.set(t),e&&P(this.inputEL?.nativeElement),e&&P(this.inputEL?.nativeElement),this.onShow.emit(),this.cd.markForCheck()}hide(e=!1){let t=()=>{this.dirty=e,this.overlayVisible=!1,this.focusedOptionIndex.set(-1),e&&P(this.inputEL?.nativeElement),this.onHide.emit(),this.cd.markForCheck()};setTimeout(()=>{t()},0)}clear(){this.updateModel(null),this.inputEL?.nativeElement&&(this.inputEL.nativeElement.value=""),this.onClear.emit()}hasSelectedOption(){return j(this.modelValue())}getAriaPosInset(e){return(this.optionGroupLabel?e-this.visibleOptions().slice(0,e).filter(t=>this.isOptionGroup(t)).length:e)+1}getOptionLabel(e){return this.optionLabel?N(e,this.optionLabel):e&&e.label!=null?e.label:e}getOptionValue(e){return this.optionValue?N(e,this.optionValue):e&&e.value!=null?e.value:e}getOptionIndex(e,t){return this.virtualScrollerDisabled?e:t&&t.getItemOptions(e).index}getOptionGroupLabel(e){return this.optionGroupLabel?N(e,this.optionGroupLabel):e&&e.label!=null?e.label:e}getOptionGroupChildren(e){return this.optionGroupChildren?N(e,this.optionGroupChildren):e.items}getPTOptions(e,t,i,o){return this.ptm(o,{context:{option:e,index:this.getOptionIndex(i,t),selected:this.isSelected(e),focused:this.focusedOptionIndex()===this.getOptionIndex(i,t),disabled:this.isOptionDisabled(e)}})}onOverlayAnimationStart(e){if(e.toState==="visible"&&(this.itemsWrapper=pe(this.overlayViewChild.overlayViewChild?.nativeElement,this.virtualScroll?".p-scroller":".p-autocomplete-panel"),this.virtualScroll&&(this.scroller?.setContentEl(this.itemsViewChild?.nativeElement),this.scroller?.viewInit()),this.visibleOptions()&&this.visibleOptions().length))if(this.virtualScroll){let t=this.modelValue()?this.focusedOptionIndex():-1;t!==-1&&this.scroller?.scrollToIndex(t)}else{let t=pe(this.itemsWrapper,".p-autocomplete-item.p-highlight");t&&t.scrollIntoView({block:"nearest",inline:"center"})}}writeControlValue(e,t){let i=this.multiple?this.visibleOptions().filter(o=>e?.some(l=>H(l,o,this.equalityKey()))):this.visibleOptions().find(o=>H(e,o,this.equalityKey()));this.value=e,t(Oe(i)?e:i),this.updateInputValue(),this.cd.markForCheck()}onDestroy(){this.scrollHandler&&(this.scrollHandler.destroy(),this.scrollHandler=null)}static \u0275fac=function(t){return new(t||n)(we(Pe),we(ke))};static \u0275cmp=K({type:n,selectors:[["p-autoComplete"],["p-autocomplete"],["p-auto-complete"]],contentQueries:function(t,i,o){if(t&1&&(I(o,zt,5),I(o,Pt,5),I(o,Rt,5),I(o,Kt,5),I(o,Qt,5),I(o,qt,5),I(o,Nt,5),I(o,Ht,5),I(o,$t,5),I(o,Gt,5),I(o,Ut,5),I(o,de,4)),t&2){let l;f(l=y())&&(i.itemTemplate=l.first),f(l=y())&&(i.emptyTemplate=l.first),f(l=y())&&(i.headerTemplate=l.first),f(l=y())&&(i.footerTemplate=l.first),f(l=y())&&(i.selectedItemTemplate=l.first),f(l=y())&&(i.groupTemplate=l.first),f(l=y())&&(i.loaderTemplate=l.first),f(l=y())&&(i.removeIconTemplate=l.first),f(l=y())&&(i.loadingIconTemplate=l.first),f(l=y())&&(i.clearIconTemplate=l.first),f(l=y())&&(i.dropdownIconTemplate=l.first),f(l=y())&&(i.templates=l)}},viewQuery:function(t,i){if(t&1&&(k(Wt,5),k(jt,5),k(Zt,5),k(Jt,5),k(Xt,5),k(Yt,5),k(ei,5)),t&2){let o;f(o=y())&&(i.inputEL=o.first),f(o=y())&&(i.multiInputEl=o.first),f(o=y())&&(i.multiContainerEL=o.first),f(o=y())&&(i.dropdownButton=o.first),f(o=y())&&(i.itemsViewChild=o.first),f(o=y())&&(i.scroller=o.first),f(o=y())&&(i.overlayViewChild=o.first)}},hostVars:4,hostBindings:function(t,i){t&1&&b("click",function(l){return i.onHostClick(l)}),t&2&&(Q(i.sx("root")),g(i.cn(i.cx("root"),i.styleClass)))},inputs:{minLength:[2,"minLength","minLength",z],minQueryLength:[2,"minQueryLength","minQueryLength",z],delay:[2,"delay","delay",z],panelStyle:"panelStyle",styleClass:"styleClass",panelStyleClass:"panelStyleClass",inputStyle:"inputStyle",inputId:"inputId",inputStyleClass:"inputStyleClass",placeholder:"placeholder",readonly:[2,"readonly","readonly",_],scrollHeight:"scrollHeight",lazy:[2,"lazy","lazy",_],virtualScroll:[2,"virtualScroll","virtualScroll",_],virtualScrollItemSize:[2,"virtualScrollItemSize","virtualScrollItemSize",z],virtualScrollOptions:"virtualScrollOptions",autoHighlight:[2,"autoHighlight","autoHighlight",_],forceSelection:[2,"forceSelection","forceSelection",_],type:"type",autoZIndex:[2,"autoZIndex","autoZIndex",_],baseZIndex:[2,"baseZIndex","baseZIndex",z],ariaLabel:"ariaLabel",dropdownAriaLabel:"dropdownAriaLabel",ariaLabelledBy:"ariaLabelledBy",dropdownIcon:"dropdownIcon",unique:[2,"unique","unique",_],group:[2,"group","group",_],completeOnFocus:[2,"completeOnFocus","completeOnFocus",_],showClear:[2,"showClear","showClear",_],dropdown:[2,"dropdown","dropdown",_],showEmptyMessage:[2,"showEmptyMessage","showEmptyMessage",_],dropdownMode:"dropdownMode",multiple:[2,"multiple","multiple",_],addOnTab:[2,"addOnTab","addOnTab",_],tabindex:[2,"tabindex","tabindex",z],dataKey:"dataKey",emptyMessage:"emptyMessage",showTransitionOptions:"showTransitionOptions",hideTransitionOptions:"hideTransitionOptions",autofocus:[2,"autofocus","autofocus",_],autocomplete:"autocomplete",optionGroupChildren:"optionGroupChildren",optionGroupLabel:"optionGroupLabel",overlayOptions:"overlayOptions",suggestions:"suggestions",optionLabel:"optionLabel",optionValue:"optionValue",id:"id",searchMessage:"searchMessage",emptySelectionMessage:"emptySelectionMessage",selectionMessage:"selectionMessage",autoOptionFocus:[2,"autoOptionFocus","autoOptionFocus",_],selectOnFocus:[2,"selectOnFocus","selectOnFocus",_],searchLocale:[2,"searchLocale","searchLocale",_],optionDisabled:"optionDisabled",focusOnHover:[2,"focusOnHover","focusOnHover",_],typeahead:[2,"typeahead","typeahead",_],addOnBlur:[2,"addOnBlur","addOnBlur",_],separator:"separator",appendTo:[1,"appendTo"]},outputs:{completeMethod:"completeMethod",onSelect:"onSelect",onUnselect:"onUnselect",onAdd:"onAdd",onFocus:"onFocus",onBlur:"onBlur",onDropdownClick:"onDropdownClick",onClear:"onClear",onInputKeydown:"onInputKeydown",onKeyUp:"onKeyUp",onShow:"onShow",onHide:"onHide",onLazyLoad:"onLazyLoad"},features:[q([on,wt,{provide:vt,useExisting:n},{provide:ue,useExisting:n}]),te([M]),ee],decls:9,vars:13,consts:[["overlay",""],["content",""],["focusInput",""],["multiContainer",""],["focusInput","","multiIn",""],["token",""],["removeicon",""],["ddBtn",""],["buildInItems",""],["scroller",""],["loader",""],["items",""],["empty",""],["pInputText","","aria-autocomplete","list","role","combobox",3,"pAutoFocus","pt","class","ngStyle","variant","invalid","pSize","fluid","input","keydown","change","focus","blur","paste","keyup",4,"ngIf"],[4,"ngIf"],["role","listbox",3,"pBind","class","tabindex","focus","blur","keydown",4,"ngIf"],["type","button","pRipple","",3,"pBind","class","disabled","click",4,"ngIf"],[3,"visibleChange","onAnimationStart","onHide","pt","hostAttrSelector","visible","options","target","appendTo","showTransitionOptions","hideTransitionOptions"],["pInputText","","aria-autocomplete","list","role","combobox",3,"input","keydown","change","focus","blur","paste","keyup","pAutoFocus","pt","ngStyle","variant","invalid","pSize","fluid"],["data-p-icon","times",3,"pBind","class","click",4,"ngIf"],[3,"pBind","class","click",4,"ngIf"],["data-p-icon","times",3,"click","pBind"],[3,"click","pBind"],[4,"ngTemplateOutlet"],["role","listbox",3,"focus","blur","keydown","pBind","tabindex"],["role","option",3,"pBind","class",4,"ngFor","ngForOf"],["role","option",3,"pBind"],["role","combobox","aria-autocomplete","list",3,"input","keydown","change","focus","blur","paste","keyup","pAutoFocus","pBind","ngStyle"],[3,"onRemove","pt","label","disabled","removable"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],[3,"pBind",4,"ngIf"],["data-p-icon","times-circle"],[3,"pBind"],["data-p-icon","spinner",3,"pBind","class","spin",4,"ngIf"],[3,"pBind","class",4,"ngIf"],["data-p-icon","spinner",3,"pBind","spin"],["type","button","pRipple","",3,"click","pBind","disabled"],[3,"ngClass",4,"ngIf"],[3,"ngClass"],["data-p-icon","chevron-down",3,"pBind",4,"ngIf"],["data-p-icon","chevron-down",3,"pBind"],[3,"pBind","ngStyle"],[3,"pt","items","style","itemSize","autoSize","lazy","options","onLazyLoad",4,"ngIf"],["role","status","aria-live","polite",1,"p-hidden-accessible"],[3,"onLazyLoad","pt","items","itemSize","autoSize","lazy","options"],["role","listbox",3,"pBind"],["ngFor","",3,"ngForOf"],["role","option",3,"pBind","class","ngStyle",4,"ngIf"],["role","option",3,"pBind","ngStyle"],["pRipple","","role","option",3,"click","mouseenter","pBind","ngStyle"],[4,"ngIf","ngIfElse"]],template:function(t,i){if(t&1){let o=T();h(0,ri,2,31,"input",13)(1,ui,3,2,"ng-container",14)(2,wi,7,36,"ul",15)(3,Ti,3,2,"ng-container",14)(4,Mi,4,8,"button",16),c(5,"p-overlay",17,0),D("visibleChange",function(x){return u(o),B(i.overlayVisible,x)||(i.overlayVisible=x),m(x)}),b("onAnimationStart",function(x){return u(o),m(i.onOverlayAnimationStart(x))})("onHide",function(){return u(o),m(i.hide())}),h(7,Yi,10,14,"ng-template",null,1,R),d()}t&2&&(r("ngIf",!i.multiple),p(),r("ngIf",i.$filled()&&!i.$disabled()&&i.showClear&&!i.loading),p(),r("ngIf",i.multiple),p(),r("ngIf",i.loading),p(),r("ngIf",i.dropdown),p(),r("pt",i.ptm("pcOverlay"))("hostAttrSelector",i.$attrSelector),F("visible",i.overlayVisible),r("options",i.overlayOptions)("target","@parent")("appendTo",i.$appendTo())("showTransitionOptions",i.showTransitionOptions)("hideTransitionOptions",i.hideTransitionOptions))},dependencies:[se,Le,Fe,Be,re,De,pt,_e,Ne,dt,me,je,Ue,Ge,ht,$,We,he,M],encapsulation:2,changeDetection:0})}return n})(),It=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=ve({type:n});static \u0275inj=be({imports:[ye,$,$]})}return n})();function an(n,a){n&1&&(c(0,"small",20),v(1,"Requis."),d())}function rn(n,a){if(n&1&&E(0,"i",26),n&2){let e=a.checked;W("pi-check",e)("pi-times",!e)}}var Tt=class n{authService=O(qe);entityService=O(Qe);userService=O(Ke);messageService=O(Ee);username="";email="";superviseur="";company="";role="PRESTATAIRE";checked=!0;address="";usernameError=!1;emailError=!1;companyError=!1;selectedEntity;selectedEntityError=!1;filteredItems=[];entities=[];ngOnInit(){this.loadSupervisor(),this.loadEntities()}loadSupervisor(){let a=this.authService.getUser();a&&(this.superviseur=a.username.split(".").map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" "))}filterItems(a){let e=(a.query||"").toLowerCase();if(!this.entities||this.entities.length===0){this.filteredItems=[];return}this.filteredItems=this.entities.filter(t=>t.code.toLowerCase().includes(e))}loadEntities(){this.entityService.getAllEntities().subscribe({next:a=>{let e=new Set,t=[];(a||[]).forEach(i=>{let o={code:i.code},l=`${o.code}`;e.has(l)||(e.add(l),t.push(o))}),this.entities=t.sort((i,o)=>i.code.localeCompare(o.code)),this.filteredItems=[]},error:a=>{console.error("Erreur lors du chargement des entit\xE9s:",a),this.messageService.add({severity:"error",summary:"Erreur",detail:"Impossible de charger les entit\xE9s.",life:4e3})}})}validateField(a){switch(a){case"username":this.usernameError=!this.username?.trim();break;case"email":this.emailError=!this.email?.trim()||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.email);break;case"company":this.companyError=!this.company?.trim();break;case"entity":this.selectedEntityError=!this.selectedEntity||!this.selectedEntity.code?.trim();break}}onSave(){if(this.validateField("username"),this.validateField("email"),this.validateField("company"),this.validateField("entity"),this.usernameError||this.emailError||this.companyError||this.selectedEntityError){this.messageService.add({severity:"error",summary:"Erreurs",detail:"Remplissez les champs obligatoires.",life:4e3});return}let a={username:this.username.trim(),email:this.email.trim(),company:this.company.trim(),address:this.address?.trim()||"",supervisor:this.authService.getUser()?.id||"",role:this.role,is_enabled:this.checked};this.userService.addUser(a).subscribe({next:e=>{console.log(e),this.messageService.add({severity:"success",summary:"Succ\xE8s",detail:"Compte prestataire cr\xE9\xE9 avec succ\xE8s.",life:4e3}),this.resetForm()},error:e=>{let t=e?.message||e?.error?.message||"Erreur lors de la cr\xE9ation du compte.";this.messageService.add({severity:"error",summary:"Erreur",detail:t,life:4e3})}})}resetForm(){this.username="",this.email="",this.company="",this.address="",this.checked=!0,this.usernameError=!1,this.emailError=!1,this.companyError=!1}static \u0275fac=function(e){return new(e||n)};static \u0275cmp=K({type:n,selectors:[["app-configuration"]],features:[q([Ee])],decls:53,vars:25,consts:[["handle",""],[1,"flex","flex-col","md:flex-row","gap-8"],[1,"card","flex","flex-col","gap-6","w-full"],[1,"font-semibold","text-xl"],[1,"flex","md:flex-col","gap-6",3,"ngSubmit"],[1,"flex","flex-col","md:flex-row","gap-6"],[1,"flex","flex-wrap","gap-2","w-full"],["for","username"],["pInputText","","id","username","type","text","name","username",3,"ngModelChange","blur","ngModel"],[1,"p-error",3,"hidden"],["for","email"],["pInputText","","id","email","type","text","name","email",3,"ngModelChange","blur","ngModel"],["for","company"],["pInputText","","id","company","type","text","name","company",3,"ngModelChange","blur","ngModel"],["for","superviseur"],["pInputText","","id","superviseur","type","text",3,"value","disabled"],["for","role"],["pInputText","","id","role","type","text",3,"disabled","value"],[1,"flex","md:flex-row","sm:flex-col","justify-between","items-center","flex-wrap","gap-2","w-full"],["id","entity","name","selectedEntity","optionLabel","code",3,"ngModelChange","completeMethod","onSelect","onBlur","ngModel","virtualScroll","suggestions","virtualScrollItemSize","dropdown","styleClass"],[1,"p-error"],["name","checked",3,"ngModelChange","ngModel"],[1,"flex","flex-wrap","gap-2"],["for","address"],["pTextarea","","id","address","rows","4","name","address",3,"ngModelChange","ngModel"],["type","submit","label","Enregistrer","icon","pi pi-check","iconPos","right"],[1,"!text-xs","pi"]],template:function(e,t){if(e&1){let i=T();c(0,"p-fluid"),E(1,"p-toast"),c(2,"div",1)(3,"div",2)(4,"div",3),v(5,"Cr\xE9er un compte au prestataire"),d(),c(6,"form",4),b("ngSubmit",function(){return u(i),m(t.onSave())}),c(7,"div",5)(8,"div",6)(9,"label",7),v(10,"Username"),d(),c(11,"input",8),D("ngModelChange",function(l){return u(i),B(t.username,l)||(t.username=l),m(l)}),b("blur",function(){return u(i),m(t.validateField("username"))}),d(),c(12,"small",9),v(13,"Requis."),d()(),c(14,"div",6)(15,"label",10),v(16,"Email"),d(),c(17,"input",11),D("ngModelChange",function(l){return u(i),B(t.email,l)||(t.email=l),m(l)}),b("blur",function(){return u(i),m(t.validateField("email"))}),d(),c(18,"small",9),v(19,"Requis et valide."),d()()(),c(20,"div",5)(21,"div",6)(22,"label",12),v(23,"Soci\xE9t\xE9"),d(),c(24,"input",13),D("ngModelChange",function(l){return u(i),B(t.company,l)||(t.company=l),m(l)}),b("blur",function(){return u(i),m(t.validateField("company"))}),d(),c(25,"small",9),v(26,"Requis."),d()(),c(27,"div",6)(28,"label",14),v(29,"Superviseur"),d(),E(30,"input",15),d()(),c(31,"div",5)(32,"div",6)(33,"label",16),v(34,"R\xF4le"),d(),E(35,"input",17),d(),c(36,"div",18)(37,"div")(38,"p"),v(39,"Entit\xE9"),d(),c(40,"p-autocomplete",19),D("ngModelChange",function(l){return u(i),B(t.selectedEntity,l)||(t.selectedEntity=l),m(l)}),b("completeMethod",function(l){return u(i),m(t.filterItems(l))})("onSelect",function(){return u(i),m(t.selectedEntityError=!1)})("onBlur",function(){return u(i),m(t.validateField("entity"))}),d(),ie(41,an,2,0,"small",20),d(),c(42,"div")(43,"p"),v(44,"Active le compte"),d(),c(45,"p-toggleswitch",21),D("ngModelChange",function(l){return u(i),B(t.checked,l)||(t.checked=l),m(l)}),h(46,rn,1,4,"ng-template",null,0,R),d()()()(),c(48,"div",22)(49,"label",23),v(50,"Adresse"),d(),c(51,"textarea",24),D("ngModelChange",function(l){return u(i),B(t.address,l)||(t.address=l),m(l)}),d()(),E(52,"p-button",25),d()()()()}e&2&&(p(11),W("p-invalid",t.usernameError),F("ngModel",t.username),p(),r("hidden",!t.usernameError),p(5),W("p-invalid",t.emailError),F("ngModel",t.email),p(),r("hidden",!t.emailError),p(6),W("p-invalid",t.companyError),F("ngModel",t.company),p(),r("hidden",!t.companyError),p(5),r("value",t.superviseur)("disabled",!0),p(5),r("disabled",!0)("value",t.role),p(5),F("ngModel",t.selectedEntity),r("virtualScroll",!0)("suggestions",t.filteredItems)("virtualScrollItemSize",40)("dropdown",!0)("styleClass",t.selectedEntityError?"p-invalid":""),p(),ne(t.selectedEntityError?41:-1),p(4),F("ngModel",t.checked),p(6),F("ngModel",t.address))},dependencies:[st,_e,$e,He,Je,Ze,ct,lt,ot,Ye,et,tt,nt,it,mt,ut,Ve,Xe,It,ye],encapsulation:2})};export{Tt as ParameterConfiguration};
