import{b,c as k,k as o,l as x}from"./chunk-IETZYUY4.js";import{ka as y,ta as h}from"./chunk-S22TW3MZ.js";import{k as g}from"./chunk-LXXOYOJP.js";import{$ as s,Ab as I,Bb as M,Cb as C,Rb as z,Sb as E,Y as l,a as S,ac as v,b as D,ba as r,bc as a,ib as p,jc as m,mb as c,nb as u,ua as d,ub as f}from"./chunk-XBUTH57D.js";var B=`
    .p-divider-horizontal {
        display: flex;
        width: 100%;
        position: relative;
        align-items: center;
        margin: dt('divider.horizontal.margin');
        padding: dt('divider.horizontal.padding');
    }

    .p-divider-horizontal:before {
        position: absolute;
        display: block;
        inset-block-start: 50%;
        inset-inline-start: 0;
        width: 100%;
        content: '';
        border-block-start: 1px solid dt('divider.border.color');
    }

    .p-divider-horizontal .p-divider-content {
        padding: dt('divider.horizontal.content.padding');
    }

    .p-divider-vertical {
        min-height: 100%;
        display: flex;
        position: relative;
        justify-content: center;
        margin: dt('divider.vertical.margin');
        padding: dt('divider.vertical.padding');
    }

    .p-divider-vertical:before {
        position: absolute;
        display: block;
        inset-block-start: 0;
        inset-inline-start: 50%;
        height: 100%;
        content: '';
        border-inline-start: 1px solid dt('divider.border.color');
    }

    .p-divider.p-divider-vertical .p-divider-content {
        padding: dt('divider.vertical.content.padding');
    }

    .p-divider-content {
        z-index: 1;
        background: dt('divider.content.background');
        color: dt('divider.content.color');
    }

    .p-divider-solid.p-divider-horizontal:before {
        border-block-start-style: solid;
    }

    .p-divider-solid.p-divider-vertical:before {
        border-inline-start-style: solid;
    }

    .p-divider-dashed.p-divider-horizontal:before {
        border-block-start-style: dashed;
    }

    .p-divider-dashed.p-divider-vertical:before {
        border-inline-start-style: dashed;
    }

    .p-divider-dotted.p-divider-horizontal:before {
        border-block-start-style: dotted;
    }

    .p-divider-dotted.p-divider-vertical:before {
        border-inline-start-style: dotted;
    }

    .p-divider-left:dir(rtl),
    .p-divider-right:dir(rtl) {
        flex-direction: row-reverse;
    }
`;var H=["*"],P={root:({instance:e})=>({justifyContent:e.layout==="horizontal"?e.align==="center"||e.align==null?"center":e.align==="left"?"flex-start":e.align==="right"?"flex-end":null:null,alignItems:e.layout==="vertical"?e.align==="center"||e.align==null?"center":e.align==="top"?"flex-start":e.align==="bottom"?"flex-end":null:null})},K={root:({instance:e})=>["p-divider p-component","p-divider-"+e.layout,"p-divider-"+e.type,{"p-divider-left":e.layout==="horizontal"&&(!e.align||e.align==="left")},{"p-divider-center":e.layout==="horizontal"&&e.align==="center"},{"p-divider-right":e.layout==="horizontal"&&e.align==="right"},{"p-divider-top":e.layout==="vertical"&&e.align==="top"},{"p-divider-center":e.layout==="vertical"&&(!e.align||e.align==="center")},{"p-divider-bottom":e.layout==="vertical"&&e.align==="bottom"}],content:"p-divider-content"},F=(()=>{class e extends h{name="divider";style=B;classes=K;inlineStyles=P;static \u0275fac=(()=>{let n;return function(t){return(n||(n=d(e)))(t||e)}})();static \u0275prov=l({token:e,factory:e.\u0275fac})}return e})();var N=new s("DIVIDER_INSTANCE"),oe=(()=>{class e extends k{$pcDivider=r(N,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=r(o,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}styleClass;layout="horizontal";type="solid";align;_componentStyle=r(F);static \u0275fac=(()=>{let n;return function(t){return(n||(n=d(e)))(t||e)}})();static \u0275cmp=p({type:e,selectors:[["p-divider"]],hostAttrs:["role","separator"],hostVars:5,hostBindings:function(i,t){i&2&&(f("aria-orientation",t.layout),v(t.sx("root")),a(t.cn(t.cx("root"),t.styleClass)))},inputs:{styleClass:"styleClass",layout:"layout",type:"type",align:"align"},features:[m([F,{provide:N,useExisting:e},{provide:b,useExisting:e}]),u([o]),c],ngContentSelectors:H,decls:2,vars:3,consts:[[3,"pBind"]],template:function(i,t){i&1&&(z(),M(0,"div",0),E(1),C()),i&2&&(a(t.cx("content")),I("pBind",t.ptm("content")))},dependencies:[g,y,x,o],encapsulation:2,changeDetection:0})}return e})();var w=`
    .p-skeleton {
        display: block;
        overflow: hidden;
        background: dt('skeleton.background');
        border-radius: dt('skeleton.border.radius');
    }

    .p-skeleton::after {
        content: '';
        animation: p-skeleton-animation 1.2s infinite;
        height: 100%;
        left: 0;
        position: absolute;
        right: 0;
        top: 0;
        transform: translateX(-100%);
        z-index: 1;
        background: linear-gradient(90deg, rgba(255, 255, 255, 0), dt('skeleton.animation.background'), rgba(255, 255, 255, 0));
    }

    [dir='rtl'] .p-skeleton::after {
        animation-name: p-skeleton-animation-rtl;
    }

    .p-skeleton-circle {
        border-radius: 50%;
    }

    .p-skeleton-animation-none::after {
        animation: none;
    }

    @keyframes p-skeleton-animation {
        from {
            transform: translateX(-100%);
        }
        to {
            transform: translateX(100%);
        }
    }

    @keyframes p-skeleton-animation-rtl {
        from {
            transform: translateX(100%);
        }
        to {
            transform: translateX(-100%);
        }
    }
`;var L={root:{position:"relative"}},O={root:({instance:e})=>["p-skeleton p-component",{"p-skeleton-circle":e.shape==="circle","p-skeleton-animation-none":e.animation==="none"}]},j=(()=>{class e extends h{name="skeleton";style=w;classes=O;inlineStyles=L;static \u0275fac=(()=>{let n;return function(t){return(n||(n=d(e)))(t||e)}})();static \u0275prov=l({token:e,factory:e.\u0275fac})}return e})();var T=new s("SKELETON_INSTANCE"),ke=(()=>{class e extends k{$pcSkeleton=r(T,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=r(o,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}styleClass;shape="rectangle";animation="wave";borderRadius;size;width="100%";height="1rem";_componentStyle=r(j);get containerStyle(){let n=this._componentStyle?.inlineStyles.root,i;return this.size?i=D(S({},n),{width:this.size,height:this.size,borderRadius:this.borderRadius}):i=D(S({},n),{width:this.width,height:this.height,borderRadius:this.borderRadius}),i}static \u0275fac=(()=>{let n;return function(t){return(n||(n=d(e)))(t||e)}})();static \u0275cmp=p({type:e,selectors:[["p-skeleton"]],hostVars:5,hostBindings:function(i,t){i&2&&(f("aria-hidden",!0),v(t.containerStyle),a(t.cn(t.cx("root"),t.styleClass)))},inputs:{styleClass:"styleClass",shape:"shape",animation:"animation",borderRadius:"borderRadius",size:"size",width:"width",height:"height"},features:[m([j,{provide:T,useExisting:e},{provide:b,useExisting:e}]),u([o]),c],decls:0,vars:0,template:function(i,t){},dependencies:[g,y],encapsulation:2,changeDetection:0})}return e})();export{oe as a,ke as b};
